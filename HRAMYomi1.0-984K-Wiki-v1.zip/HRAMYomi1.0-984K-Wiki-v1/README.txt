HRAMYomi1.0
==============================

First HRAMY Omni language model.

Model:
- 984,192 parameters
- Decoder-only Transformer
- Byte-level UTF-8 tokenizer
- 128-token context
- 4 Transformer layers
- 4 attention heads
- d_model = 128
- FFN = 448
- RMSNorm
- RoPE
- SwiGLU
- Causal self-attention
- Tied embedding / LM head

Training:
- Dataset: English Wikipedia
- Approximately 100 MB of training corpus
- Best checkpoint: step 9000
- Validation loss: 1.442016
- Validation perplexity: 4.2292

This is the first HRAMYomi baseline model.

It is intentionally small and was designed with eventual
FPGA implementation in mind.

The model was trained from scratch without using a
pretrained language model.
